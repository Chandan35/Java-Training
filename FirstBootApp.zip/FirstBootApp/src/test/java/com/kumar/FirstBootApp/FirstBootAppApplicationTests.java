package com.kumar.FirstBootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
